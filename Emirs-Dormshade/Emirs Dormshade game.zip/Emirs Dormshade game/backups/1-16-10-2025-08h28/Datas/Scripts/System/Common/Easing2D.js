/**
 * The static class who handle easing in 2D
 */
export class Easing {
    constructor() {
        throw new Error("This is a static class");
    }
}
