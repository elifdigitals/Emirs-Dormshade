import * as RPM from "../System/index.js"

export { RPM }